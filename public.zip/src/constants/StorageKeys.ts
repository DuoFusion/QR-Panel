export const STORAGE_KEYS = {
  USER: 'hk_qr_admin_user',
  TOKEN: 'hk_qr_admin_token',
  FORGOT_PASSWORD_EMAIL: 'hk_qr_admin_forgot_password_email',
} as const
