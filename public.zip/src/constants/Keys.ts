export const KEYS = {
  LOGIN: "admin-login",
  SEND_PASSWORD_EMAIL: "forgot-password-request",
  VERIFY_OTP: "verify-otp",
  RESET_PASSWORD: "reset-password",
  
  RESEND_OTP: "resend-otp",
  USER: "user-details",
  PASSWORD_UPDATE: "password-update",
  ALL_TEAMS: "all-teams",
} as const;
