import { createBrowserRouter } from "react-router-dom";
import ForgotPasswordContainer from "../auth/forgotPassword";
import LoginContainer from "../auth/login";
import ResetPasswordContainer from "../auth/resetPassword";
import VerifyOtpContainer from "../auth/verifyOtp";
import Dashboard from "../components/dashboard";
import { ROUTES } from "../constants";
import Layout from "../layout";
import PrivateRoutes from "./PrivateRoutes";
import PublicRoutes from "./PublicRoutes";
import ChangePasswordContainer from "../auth/changePassword";

export const Router = createBrowserRouter([
  {
    element: <PrivateRoutes />,
    children: [
      {
        element: <Layout />,
        children: [
          { path: ROUTES.HOME, element: <Dashboard /> },
          { path: ROUTES.CHANGE_PASSWORD, element: <ChangePasswordContainer /> },
        ],
      },
    ],
  },
  {
    element: <PublicRoutes />,
    children: [
      { path: ROUTES.LOGIN, element: <LoginContainer /> },
      { path: ROUTES.FORGOT_PASSWORD, element: <ForgotPasswordContainer /> },
      { path: ROUTES.VERIFY_OTP, element: <VerifyOtpContainer /> },
      { path: ROUTES.Reset_PASSWORD, element: <ResetPasswordContainer /> },
    ],
  },
  {
    path: "*",
    // element: <ErrorPage />,
  },
]);
