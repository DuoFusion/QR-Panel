import { Button } from "antd";
import { Form, Formik } from "formik";
import { Link, useNavigate } from "react-router-dom";
import { Card, CardBody, Col, Container, Row } from "reactstrap";
import { Mutations } from "../../api";
import { ROUTES } from "../../constants";
import { TextInput } from "../../shared/formFields";
import { useAppDispatch } from "../../store/hooks";
import { loginSuccess } from "../../store/slices/AuthSlice";
import { LoginPayload } from "../../types";
import { LoginSchema } from "../../utils/validationSchemas";
import { Fragment } from "react/jsx-runtime";
import Breadcrumbs from "../../coreComponents/Breadcrumbs";
import CommonCardHeader from "../../coreComponents/cardHeader";

const ChangePasswordContainer = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { mutate: Login, isPending } = Mutations.useLogin();

  const handleSubmit = async (values: LoginPayload) => {
    Login(values, {
      onSuccess: (response) => {
        dispatch(loginSuccess(response?.data));
        navigate(ROUTES.DASHBOARD);
      },
    });
  };

  return (
    <Fragment>
      <Breadcrumbs mainTitle="Change Password" parent="Pages" />
      <Container fluid>
        <Col md="12">
          <Card>
            <CommonCardHeader title="Change Password" />
            <CardBody>
              <div className="input-items">
                <Formik initialValues={{ email: "", password: "" }} validationSchema={LoginSchema} onSubmit={handleSubmit}>
                  {() => (
                    <Form>
                      <Row className="gy-3">
                        <Col md="12">
                          <TextInput label="email address" name="email" type="email" placeholder="rarex49098@firain.com" required/>
                        </Col>
                        <Col md="12">
                          <TextInput name="password" label="password" type="password" placeholder="*********" required/>
                        </Col>
                        <Col>
                          <div className="text-center mt-1">
                            <Button htmlType="submit" type="primary" className="btn btn-primary" size="large" loading={isPending}>
                              Login
                            </Button>
                          </div>
                        </Col>
                      </Row>
                    </Form>
                  )}
                </Formik>
                {/* <Form onSubmit={handleSubmit(onSubmit)}>
                  <Row className="gy-3">
                    <Col md="12">
                      <div className="input-box">
                        <Label>Old Password</Label>
                        <input type="text" {...register("oldPassword")} placeholder="Enter Old Password" />
                        {errors.oldPassword && <p className="text-danger">{errors.oldPassword.message}</p>}
                      </div>
                    </Col>

                    <Col md="6">
                      <div className="input-box">
                        <Label>New Password</Label>
                        <input type="text" {...register("newPassword")} placeholder="Enter New Password" />
                        {errors.newPassword && <p className="text-danger">{errors.newPassword.message}</p>}
                      </div>
                    </Col>

                    <Col md="6">
                      <div className="input-box">
                        <Label>Confirm Password</Label>
                        <input type="text" {...register("confirmPassword")} placeholder="Enter Confirm password" />
                        {errors.confirmPassword && <p className="text-danger">{errors.confirmPassword.message}</p>}
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <div className="text-center mt-4">
                        <Button htmlType="submit" className="btn btn-primary" loading={loading}>
                          Save
                        </Button>
                      </div>
                    </Col>
                  </Row>
                </Form> */}
              </div>
            </CardBody>
          </Card>
        </Col>
      </Container>
    </Fragment>
  );
};

export default ChangePasswordContainer;
