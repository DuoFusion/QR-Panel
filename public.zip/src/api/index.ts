import Delete from "./Delete";
import Get from "./Get";
import Mutations from "./Mutations";
import Post from "./Post";
import Queries from "./Queries";

export { Get, Mutations, Post, Queries, Delete };
