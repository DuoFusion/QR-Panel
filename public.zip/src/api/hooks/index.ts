import useApiPost from "./useApiPost";
import useApiGet from "./useApiGet";
import useApiDelete from "./useApiDelete";

export { useApiPost, useApiGet, useApiDelete };
